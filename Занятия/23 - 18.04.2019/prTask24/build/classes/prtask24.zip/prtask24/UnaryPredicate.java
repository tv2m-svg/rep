package prtask24;

public interface UnaryPredicate<T> {
    boolean test(T obj);
}
